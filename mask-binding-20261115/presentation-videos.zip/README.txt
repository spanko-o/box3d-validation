Object control and predicted masks — 2026-11-15
57 frames / 8 fps. Videos use English labels.
Color series, police/firefighter and bus occlusion: local inference, step-5000 weights.
Mattress secured: current training validation, step 1500. Mattress/ladder dropping: prior training validation, step 7000.
GT panels are real video for color cases. Event and two-person generation videos are provided individually; predicted-mask videos are separate files.
Cyan/orange overlays are predicted mask-derived read support, not ground-truth segmentation.
Bus occlusion: text targets the rear bus; the foreground car has no object caption. Cyan = bus target, orange = foreground car in GT. Its step-48 predicted mask is used at final denoising step 49.
Color names and police/firefighter descriptions are requested conditions, not evaluation labels.
