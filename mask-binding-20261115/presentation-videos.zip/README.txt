Object control and predicted masks — 2026-11-15
57 frames / 8 fps. Videos use English labels.
Color series and police/firefighter: local inference, step-5000 weights.
Mattress and ladder: prior training validation, step 7000.
GT panels are real video for color cases. Event and two-person generation videos are provided individually; predicted-mask videos are separate files.
Cyan/orange overlays are predicted mask-derived read support, not ground-truth segmentation.
Color names and police/firefighter descriptions are requested conditions, not evaluation labels.
